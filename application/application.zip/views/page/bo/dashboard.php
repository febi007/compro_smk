<?php $this->load->view('layout/header')
 ?>

<button class="btn btn-success"><a href="<?=base_url();?>Bo_Controller/jurusan">Jurusan</a></button>