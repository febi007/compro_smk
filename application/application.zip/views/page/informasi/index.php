<?php
$this->load->view('page/informasi/tenaga_pen');
$this->load->view('page/informasi/prestasi');
$this->load->view('page/informasi/sarana');
$this->load->view('page/informasi/akreditasi');
$this->load->view('page/informasi/lowongan_kerja');

?>