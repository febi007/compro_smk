<?php
$this->load->view('page/selayang/sejarah');
$this->load->view('page/selayang/visi_misi');
$this->load->view('page/selayang/budaya');
$this->load->view('page/selayang/landasan_hukum');
$this->load->view('page/selayang/fasilitas');

?>