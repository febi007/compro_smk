
<section class="inner-banner">
    <div class="container">
        <h2 class="inner-banner__title text"></h2><!-- /.inner-banner__title -->
    </div><!-- /.container -->
</section>