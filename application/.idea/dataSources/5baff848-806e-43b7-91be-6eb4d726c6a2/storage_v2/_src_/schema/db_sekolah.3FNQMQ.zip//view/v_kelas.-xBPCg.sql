create view v_kelas as
  select
    `tk`.`id`         AS `id`,
    `tk`.`id_jurusan` AS `id_jurusan`,
    `tk`.`nama`       AS `nama`,
    `tk`.`created_at` AS `created_at`,
    `tk`.`updated_at` AS `updated_at`,
    `tj`.`title`      AS `jurusan`
  from (`db_sekolah`.`tbl_kelas` `tk`
    join `db_sekolah`.`tbl_jurusan` `tj` on ((`tk`.`id_jurusan` = `tj`.`id`)));

